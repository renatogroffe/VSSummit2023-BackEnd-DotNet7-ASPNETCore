# ASPNETCore7-WebApi-RateLimitingFixedWindow-StatusCode429_ContagemAcessos
Exemplo de API REST para contagem de acessos criada com .NET 7 + ASP.NET Core (Web API template), com Rate Limiting utilizando o modo Fixed Window e customização para uso do HTTP Status Code 429 (Too Many Requests). Inclui um Dockerfile para a geração de imagens baseadas em Linux.
